import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, Target, PenTool, BarChart3, Shield, Globe } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const GuestPosts = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const detailsRef = useRef<HTMLDivElement>(null);
  const processRef = useRef<HTMLDivElement>(null);
  const sitesRef = useRef<HTMLDivElement>(null);
  const faqRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.guest-hero-image', { x: '-25vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.guest-hero-content', { x: '12vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.15 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: detailsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.detail-card', { y: 25, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: processRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.process-step', { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: sitesRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.site-category', { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: faqRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.faq-item', { y: 12, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out', stagger: 0.06 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  const details = [
    { icon: Target, title: 'Niche-Relevant Outreach', description: 'We identify and target websites that your audience actually visits. No generic placements—every site is vetted for relevance and authority.' },
    { icon: PenTool, title: 'Editorial-Quality Content', description: 'Our writers create engaging, valuable content that publications want to publish. Every article is original, well-researched, and aligned with your brand voice.' },
    { icon: BarChart3, title: 'Transparent Reporting', description: "Track every outreach, pitch, and placement in real-time. You'll know exactly where your links are coming from and the metrics behind each site." },
    { icon: Shield, title: 'White-Hat Only', description: "We follow Google's guidelines. No PBNs, no link farms, no shortcuts. Just genuine outreach that builds lasting authority." },
  ];

  const process = [
    { step: '01', title: 'Discovery', description: 'We learn about your business, goals, and target audience to create a tailored outreach strategy.' },
    { step: '02', title: 'Site Research', description: 'Our team identifies high-authority websites in your niche with engaged readerships.' },
    { step: '03', title: 'Content Creation', description: 'We craft compelling articles that provide value to readers while naturally incorporating your expertise.' },
    { step: '04', title: 'Outreach & Placement', description: 'We pitch editors and secure placements, handling all communication and revisions.' },
    { step: '05', title: 'Delivery & Reporting', description: 'You receive live links, placement details, and performance metrics in a comprehensive report.' },
  ];

  const siteCategories = [
    { category: 'Technology', metrics: 'DA 50-80', examples: ['Tech blogs', 'SaaS publications', 'Developer communities'] },
    { category: 'Business', metrics: 'DA 45-75', examples: ['Entrepreneurship sites', 'Leadership blogs', 'Industry publications'] },
    { category: 'Health & Wellness', metrics: 'DA 40-70', examples: ['Medical blogs', 'Fitness publications', 'Wellness platforms'] },
    { category: 'Finance', metrics: 'DA 55-85', examples: ['Fintech blogs', 'Investment sites', 'Personal finance publications'] },
  ];

  const faqs = [
    { question: 'How long does it take to get placements?', answer: 'Most campaigns begin seeing live links within 2-4 weeks, with the bulk delivered over 60-90 days. Timeline depends on niche competitiveness and content complexity.' },
    { question: 'Do you guarantee specific sites?', answer: 'We guarantee relevance and quality metrics; exact sites depend on editorial fit and timing.' },
    { question: 'What niches do you work with?', answer: 'We specialize in B2B SaaS, fintech, health, e-commerce, and professional services. Contact us if your niche is not listed.' },
    { question: 'Is the content included?', answer: 'Yes—pitch angles, article drafts, and revisions are all part of the package. Our writers create content that matches each publication style.' },
    { question: 'How do you ensure link quality?', answer: 'Every site is manually vetted for domain authority, organic traffic, editorial standards, and relevance. We only pursue placements that will genuinely benefit your SEO.' },
  ];

  return (
    <div className="bg-[#F6F7F6] pt-20">
      {/* Hero Section */}
      <section ref={heroRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="guest-hero-image relative order-2 lg:order-1">
              <div className="relative rounded-[18px] overflow-hidden shadow-lg">
                <img src="/images/guestpost_writing.jpg" alt="Guest post writing" className="w-full h-[320px] md:h-[380px] lg:h-[420px] object-cover" />
              </div>
            </div>

            <div className="guest-hero-content order-1 lg:order-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-0.5 bg-[#2F6BFF]" />
                <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">Guest Post Service</span>
              </div>
              <h1 className="font-serif text-3xl md:text-4xl lg:text-[46px] font-semibold text-[#0B0D0E] leading-[1.08] mb-4">
                Earn backlinks from respected sites.
              </h1>
              <p className="text-base lg:text-lg text-[#6E757C] leading-relaxed mb-6 max-w-md">
                We write and place articles on blogs your audience already trusts—so you rank higher and convert better.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5">
                  Get started<ArrowRight size={16} />
                </Link>
                <Link to="/services" className="inline-flex items-center gap-2 px-6 py-3 border border-[#0B0D0E]/15 text-[#0B0D0E] text-sm font-medium rounded-full hover:bg-[#0B0D0E] hover:text-white transition-all">
                  View all services
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What You Get */}
      <section ref={detailsRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">What you get</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">A complete guest post service that handles everything from strategy to delivery.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {details.map((detail) => (
              <div key={detail.title} className="detail-card bg-white rounded-[14px] p-5 shadow-md hover:shadow-lg transition-shadow">
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center mb-4">
                  <detail.icon size={20} className="text-[#2F6BFF]" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-[#0B0D0E] mb-2">{detail.title}</h3>
                <p className="text-sm text-[#6E757C] leading-relaxed">{detail.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section ref={processRef} className="py-8 px-6 lg:px-12 xl:px-20 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">Our process</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">A proven system that delivers consistent results.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {process.map((step) => (
              <div key={step.step} className="process-step relative">
                <div className="text-3xl lg:text-4xl font-serif font-bold text-[#2F6BFF]/10 mb-2">{step.step}</div>
                <h3 className="font-serif text-base font-semibold text-[#0B0D0E] mb-1">{step.title}</h3>
                <p className="text-xs text-[#6E757C] leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Site Categories */}
      <section ref={sitesRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">Sites we work with</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">We place content on authoritative sites across major industries.</p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {siteCategories.map((cat) => (
              <div key={cat.category} className="site-category bg-white rounded-[14px] p-4 shadow-md">
                <div className="flex items-center gap-2 mb-2">
                  <Globe size={16} className="text-[#2F6BFF]" />
                  <span className="text-xs font-medium text-[#2F6BFF]">{cat.metrics}</span>
                </div>
                <h3 className="font-serif text-lg font-semibold text-[#0B0D0E] mb-2">{cat.category}</h3>
                <ul className="space-y-0.5">
                  {cat.examples.map((example) => (
                    <li key={example} className="text-xs text-[#6E757C]">{example}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section ref={faqRef} className="py-8 px-6 lg:px-12 xl:px-20 bg-white">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] mb-3">Frequently asked questions</h2>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div key={index} className="faq-item bg-[#F6F7F6] rounded-[12px] p-4">
                <h3 className="font-medium text-sm text-[#0B0D0E] mb-2 flex items-start gap-2">
                  <Check size={16} className="text-[#2F6BFF] mt-0.5 flex-shrink-0" />
                  {faq.question}
                </h3>
                <p className="text-xs text-[#6E757C] leading-relaxed pl-6">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-lg mx-auto text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] mb-3">Ready to start building backlinks?</h2>
          <p className="text-base text-[#6E757C] mb-5 max-w-sm mx-auto">Let's discuss your goals and create a custom guest post strategy.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5 hover:shadow-lg">
            Request a proposal<ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default GuestPosts;
