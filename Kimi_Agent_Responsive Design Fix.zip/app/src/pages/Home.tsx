import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Home = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const whatWeDoRef = useRef<HTMLDivElement>(null);
  const guestPostsRef = useRef<HTMLDivElement>(null);
  const pressCoverageRef = useRef<HTMLDivElement>(null);
  const metricsRef = useRef<HTMLDivElement>(null);
  const processRef = useRef<HTMLDivElement>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.hero-image', { x: '-30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 1, ease: 'power2.out' });
      gsap.fromTo('.hero-content', { x: '10vw', opacity: 0 }, { x: 0, opacity: 1, duration: 1, ease: 'power2.out', delay: 0.2 });
      gsap.fromTo('.hero-cta', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out', delay: 0.4 });

      ScrollTrigger.create({
        trigger: whatWeDoRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.whatwedo-image', { x: '30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.whatwedo-headline', { x: '-15vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.1 });
          gsap.fromTo('.whatwedo-body', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', delay: 0.2 });
          gsap.fromTo('.whatwedo-chip', { y: 15, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.05, delay: 0.3 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: guestPostsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.guestpost-image', { x: '-30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.guestpost-headline', { x: '15vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.1 });
          gsap.fromTo('.guestpost-bullet', { y: 15, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08, delay: 0.3 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: pressCoverageRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.press-image', { x: '30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.press-headline', { x: '-15vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.1 });
          gsap.fromTo('.press-chip', { y: 15, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.06, delay: 0.3 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: metricsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.metrics-image', { x: '-30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.metrics-headline', { x: '15vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.1 });
          gsap.fromTo('.metrics-stat', { y: 25, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1, delay: 0.25 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: processRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.process-title', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' });
          gsap.fromTo('.process-card', { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1, delay: 0.15 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: testimonialsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.testimonial-image', { x: '30vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.testimonial-content', { x: '-15vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.1 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  return (
    <div className="bg-[#F6F7F6]">
      {/* Hero Section */}
      <section ref={heroRef} className="pt-24 pb-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="hero-image relative order-2 lg:order-1">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/hero_workspace.jpg" alt="Modern workspace" className="w-full h-[350px] md:h-[450px] lg:h-[520px] object-cover" />
              </div>
            </div>

            <div className="hero-content order-1 lg:order-2">
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-0.5 bg-[#2F6BFF]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">Digital PR & Link Building</span>
                </div>
                <h1 className="font-serif text-4xl md:text-5xl lg:text-[56px] font-semibold text-[#0B0D0E] leading-[1.08]">
                  Build authority.<br />Get featured.<br />Grow faster.
                </h1>
                <p className="text-base lg:text-lg text-[#6E757C] max-w-md leading-relaxed">
                  We land guest posts on respected sites and press coverage that earns trust—and rankings.
                </p>
                <div className="hero-cta flex flex-wrap gap-3 pt-1">
                  <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all">
                    Request a proposal<ArrowRight size={16} />
                  </Link>
                  <Link to="/services" className="inline-flex items-center gap-2 px-6 py-3 border border-[#0B0D0E]/15 text-[#0B0D0E] text-sm font-medium rounded-full hover:bg-[#0B0D0E] hover:text-white transition-all">
                    See our services
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What We Do */}
      <section ref={whatWeDoRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="lg:pr-8">
              <h2 className="whatwedo-headline font-serif text-3xl md:text-4xl lg:text-[44px] font-semibold text-[#0B0D0E] leading-[1.1] mb-4">
                Guest posts. Press coverage. Real results.
              </h2>
              <p className="whatwedo-body text-base lg:text-lg text-[#6E757C] max-w-md leading-relaxed mb-5">
                We handle outreach, pitching, and placement—so you get backlinks and brand mentions without the busywork.
              </p>
              <div className="flex flex-wrap gap-2 mb-5">
                {['Guest Posts', 'Digital PR', 'Link Building', 'Content Strategy'].map((chip, i) => (
                  <span key={chip} className={`whatwedo-chip px-3 py-1.5 text-xs font-medium rounded-full border ${i === 0 ? 'bg-[#2F6BFF] text-white border-[#2F6BFF]' : 'bg-white text-[#0B0D0E] border-[#0B0D0E]/10 hover:border-[#2F6BFF]'}`}>
                    {chip}
                  </span>
                ))}
              </div>
              <Link to="/services" className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium hover:gap-3 transition-all">
                Explore services<ArrowRight size={16} />
              </Link>
            </div>

            <div className="whatwedo-image relative">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/whatwedo_meeting.jpg" alt="Team meeting" className="w-full h-[300px] md:h-[380px] lg:h-[420px] object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Guest Posts */}
      <section ref={guestPostsRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="guestpost-image relative order-2 lg:order-1">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/guestpost_writing.jpg" alt="Content writing" className="w-full h-[350px] md:h-[420px] lg:h-[480px] object-cover" />
              </div>
            </div>

            <div className="order-1 lg:order-2 lg:pl-8">
              <h2 className="guestpost-headline font-serif text-3xl md:text-4xl lg:text-[44px] font-semibold text-[#0B0D0E] leading-[1.1] mb-4">
                Earn backlinks from respected sites.
              </h2>
              <p className="text-base lg:text-lg text-[#6E757C] max-w-md leading-relaxed mb-5">
                We write and place articles on blogs your audience already trusts—so you rank higher and convert better.
              </p>
              <ul className="space-y-3 mb-5">
                {['Niche-relevant outreach', 'Editorial-quality content', 'Transparent reporting'].map((item) => (
                  <li key={item} className="guestpost-bullet flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0">
                      <Check size={12} className="text-[#2F6BFF]" />
                    </div>
                    <span className="text-[#0B0D0E] text-sm font-medium">{item}</span>
                  </li>
                ))}
              </ul>
              <Link to="/services/guest-posts" className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium hover:gap-3 transition-all">
                See guest post sites<ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Press Coverage */}
      <section ref={pressCoverageRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="lg:pr-8">
              <h2 className="press-headline font-serif text-3xl md:text-4xl lg:text-[44px] font-semibold text-[#0B0D0E] leading-[1.1] mb-4">
                Get featured where it matters.
              </h2>
              <p className="text-base lg:text-lg text-[#6E757C] max-w-md leading-relaxed mb-5">
                From product launches to company stories—we pitch journalists and secure placements that build credibility.
              </p>
              <div className="flex flex-wrap gap-2 mb-5">
                {['Brand awareness', 'SEO authority', 'Referral traffic'].map((chip, i) => (
                  <span key={chip} className={`press-chip px-3 py-1.5 text-xs font-medium rounded-full border ${i === 1 ? 'bg-[#2F6BFF] text-white border-[#2F6BFF]' : 'bg-white text-[#0B0D0E] border-[#0B0D0E]/10 hover:border-[#2F6BFF]'}`}>
                    {chip}
                  </span>
                ))}
              </div>
              <Link to="/services/press-releases" className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium hover:gap-3 transition-all">
                View press examples<ArrowRight size={16} />
              </Link>
            </div>

            <div className="press-image relative">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/press_camera.jpg" alt="Press and media" className="w-full h-[280px] md:h-[340px] lg:h-[400px] object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics */}
      <section ref={metricsRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="metrics-image relative order-2 lg:order-1">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/metrics_portrait.jpg" alt="Professional portrait" className="w-full h-[350px] md:h-[420px] lg:h-[480px] object-cover" />
              </div>
            </div>

            <div className="order-1 lg:order-2 lg:pl-8">
              <h2 className="metrics-headline font-serif text-3xl md:text-4xl lg:text-[44px] font-semibold text-[#0B0D0E] leading-[1.1] mb-6">
                Faster rankings.<br />Stronger trust.
              </h2>
              <div className="space-y-4 mb-6">
                {[
                  { value: '3×', label: 'Average backlink growth in 90 days' },
                  { value: '40+', label: 'Average placements per campaign' },
                  { value: '92%', label: 'Client retention rate' },
                ].map((stat) => (
                  <div key={stat.label} className="metrics-stat flex items-baseline gap-3">
                    <span className="font-serif text-4xl lg:text-5xl font-semibold text-[#2F6BFF]">{stat.value}</span>
                    <span className="text-[#6E757C] text-sm">{stat.label}</span>
                  </div>
                ))}
              </div>
              <Link to="/about" className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium hover:gap-3 transition-all">
                See case studies<ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section ref={processRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="process-title font-serif text-3xl md:text-4xl font-semibold text-[#0B0D0E] mb-3">How it works</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">A simple, repeatable system—so you always know what's next.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              { step: '1', title: 'Strategy', description: 'We map your goals, audience, and target sites.' },
              { step: '2', title: 'Outreach', description: 'We pitch editors and secure placements.' },
              { step: '3', title: 'Delivery', description: 'You get live links, coverage, and reporting.' },
            ].map((item) => (
              <div key={item.step} className="process-card bg-white rounded-[18px] p-6 shadow-md hover:shadow-lg transition-shadow">
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF] text-white flex items-center justify-center text-lg font-semibold mb-4">{item.step}</div>
                <h3 className="font-serif text-xl font-semibold text-[#0B0D0E] mb-2">{item.title}</h3>
                <p className="text-sm text-[#6E757C] leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section ref={testimonialsRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="testimonial-content lg:pr-8">
              <h2 className="font-serif text-3xl md:text-4xl lg:text-[44px] font-semibold text-[#0B0D0E] leading-[1.1] mb-5">
                Clients trust us to deliver.
              </h2>
              <div className="relative mb-5">
                <span className="absolute -top-2 -left-1 font-serif text-6xl text-[#2F6BFF] opacity-10">"</span>
                <blockquote className="relative text-lg text-[#0B0D0E] leading-relaxed font-medium">
                  LinkBoost turned our launches into coverage—and coverage into revenue. The team moves fast and thinks like journalists.
                </blockquote>
              </div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center">
                  <span className="font-serif text-sm font-semibold text-[#2F6BFF]">SC</span>
                </div>
                <div>
                  <p className="font-medium text-[#0B0D0E] text-sm">Sarah Chen</p>
                  <p className="text-xs text-[#6E757C]">CMO</p>
                </div>
              </div>
              <Link to="/about" className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium hover:gap-3 transition-all">
                Read more stories<ArrowRight size={16} />
              </Link>
            </div>

            <div className="testimonial-image relative">
              <div className="relative rounded-[20px] overflow-hidden shadow-lg">
                <img src="/images/testimonial_team.jpg" alt="Team collaboration" className="w-full h-[280px] md:h-[340px] lg:h-[400px] object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 px-6 lg:px-12 xl:px-20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-semibold text-[#0B0D0E] mb-4">Ready to boost your authority?</h2>
          <p className="text-base text-[#6E757C] mb-6 max-w-md mx-auto">Let's discuss how we can help you get featured on the sites that matter.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5">
            Request a proposal<ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
