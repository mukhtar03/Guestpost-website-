import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, Globe, Newspaper, TrendingUp, FileText } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Services = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);
  const benefitsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.services-hero-content', { y: 25, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: servicesRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.service-card', { y: 35, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out', stagger: 0.12 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: benefitsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.benefit-item', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  const services = [
    {
      icon: Globe,
      title: 'Guest Post Links',
      description: 'Earn high-quality backlinks from authoritative websites in your niche. We handle everything from outreach to content creation.',
      features: ['Niche-relevant sites', 'DA 40+ placements', 'Editorial content included'],
      link: '/services/guest-posts',
      image: '/images/guestpost_writing.jpg',
    },
    {
      icon: Newspaper,
      title: 'Press Releases',
      description: 'Get featured in top-tier publications and industry blogs. Build brand authority with strategic media coverage.',
      features: ['Journalist outreach', 'News angle crafting', 'Publication tracking'],
      link: '/services/press-releases',
      image: '/images/press_camera.jpg',
    },
  ];

  const benefits = [
    { icon: TrendingUp, title: 'Improved Rankings', description: 'Quality backlinks that boost your search visibility' },
    { icon: Globe, title: 'Brand Authority', description: 'Get mentioned on sites your audience trusts' },
    { icon: FileText, title: 'Content Included', description: 'Professional writing that matches each publication' },
    { icon: Check, title: 'Transparent Reporting', description: 'Track every placement and link in real-time' },
  ];

  return (
    <div className="bg-[#F6F7F6] pt-20">
      {/* Hero Section */}
      <section ref={heroRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-3xl mx-auto text-center">
          <div className="services-hero-content">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-8 h-0.5 bg-[#2F6BFF]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">Our Services</span>
              <div className="w-8 h-0.5 bg-[#2F6BFF]" />
            </div>
            <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-[#0B0D0E] leading-[1.08] mb-4">
              Digital PR & Link Building
            </h1>
            <p className="text-base lg:text-lg text-[#6E757C] max-w-xl mx-auto leading-relaxed">
              We help brands earn authority through strategic guest posts and press coverage. Every placement is earned, every link is valuable.
            </p>
          </div>
        </div>
      </section>

      {/* Services Cards */}
      <section ref={servicesRef} className="py-6 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {services.map((service) => (
              <div
                key={service.title}
                className="service-card group bg-white rounded-[18px] overflow-hidden shadow-md hover:shadow-lg transition-all"
              >
                <div className="relative h-48 lg:h-52 overflow-hidden">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center mb-2">
                      <service.icon size={20} className="text-[#2F6BFF]" />
                    </div>
                    <h2 className="font-serif text-xl lg:text-2xl font-semibold text-white">{service.title}</h2>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-sm text-[#6E757C] leading-relaxed mb-4">{service.description}</p>
                  <ul className="space-y-2 mb-5">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0">
                          <Check size={10} className="text-[#2F6BFF]" />
                        </div>
                        <span className="text-[#0B0D0E] text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to={service.link} className="inline-flex items-center gap-2 text-sm text-[#2F6BFF] font-medium group-hover:gap-3 transition-all">
                    Learn more<ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section ref={benefitsRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">
              Why brands choose LinkBoost
            </h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">
              We're not just another link building agency. We're your PR partner.
            </p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((benefit) => (
              <div
                key={benefit.title}
                className="benefit-item bg-white rounded-[14px] p-4 lg:p-5 shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center mb-3">
                  <benefit.icon size={18} className="text-[#2F6BFF]" />
                </div>
                <h3 className="font-serif text-base lg:text-lg font-semibold text-[#0B0D0E] mb-1">{benefit.title}</h3>
                <p className="text-xs text-[#6E757C] leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-xl mx-auto">
          <div className="bg-[#0B0D0E] rounded-[18px] p-6 lg:p-8 text-center">
            <h2 className="font-serif text-xl lg:text-2xl font-semibold text-[#F6F7F6] mb-3">
              Ready to get started?
            </h2>
            <p className="text-sm text-[#F6F7F6]/65 max-w-sm mx-auto mb-5">
              Tell us about your goals and we'll create a custom strategy for your brand.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5"
            >
              Request a proposal<ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
