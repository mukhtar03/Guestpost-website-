import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, Users, Globe, TrendingUp } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const storyRef = useRef<HTMLDivElement>(null);
  const valuesRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.about-hero-content', { y: 25, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: storyRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.story-image', { x: '-20vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.story-content', { x: '12vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.15 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: valuesRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.value-card', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: statsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.stat-item', { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  const values = [
    { icon: Award, title: 'Quality First', description: 'We never compromise on the quality of our outreach or the content we create. Every placement must meet our standards.' },
    { icon: Users, title: 'Partnership Mindset', description: "We see ourselves as an extension of your team. Your success is our success, and we're invested in long-term growth." },
    { icon: Globe, title: 'Global Reach', description: 'With team members across time zones, we can execute campaigns and respond to opportunities around the clock.' },
    { icon: TrendingUp, title: 'Data-Driven', description: 'We track everything and use data to refine our approach. What gets measured gets improved.' },
  ];

  const stats = [
    { value: '500+', label: 'Campaigns Delivered' },
    { value: '10K+', label: 'Links Secured' },
    { value: '150+', label: 'Publications' },
    { value: '92%', label: 'Client Retention' },
  ];

  return (
    <div className="bg-[#F6F7F6] pt-20">
      {/* Hero Section */}
      <section ref={heroRef} className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-3xl mx-auto text-center">
          <div className="about-hero-content">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-8 h-0.5 bg-[#2F6BFF]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">About Us</span>
              <div className="w-8 h-0.5 bg-[#2F6BFF]" />
            </div>
            <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-[#0B0D0E] leading-[1.08] mb-4">
              We build authority<br className="hidden sm:block" />for brands that matter.
            </h1>
            <p className="text-base lg:text-lg text-[#6E757C] max-w-xl mx-auto leading-relaxed">
              LinkBoost is a digital PR and link building agency focused on one thing: 
              helping brands earn the visibility and authority they deserve.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section ref={storyRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-center">
            <div className="story-image relative">
              <div className="relative rounded-[18px] overflow-hidden shadow-lg">
                <img src="/images/whatwedo_meeting.jpg" alt="Our team" className="w-full h-[280px] md:h-[340px] lg:h-[400px] object-cover" />
              </div>
            </div>

            <div className="story-content">
              <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] leading-[1.12] mb-4">
                Our story
              </h2>
              <div className="space-y-3 text-sm lg:text-base text-[#6E757C] leading-relaxed">
                <p>
                  LinkBoost was founded with a simple belief: the best marketing is earned, not bought. 
                  In a world of paid ads and interruptive marketing, we saw an opportunity to help brands 
                  build lasting authority through genuine media coverage and valuable content.
                </p>
                <p>
                  What started as a small team of PR professionals and SEO experts has grown into a 
                  global agency serving clients across industries—from fast-growing startups to established 
                  enterprises.
                </p>
                <p>
                  We combine journalistic instincts with SEO expertise. Our team includes former reporters, 
                  editors, and content strategists who understand what publications want and what audiences 
                  need.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section ref={statsRef} className="py-8 px-6 lg:px-12 xl:px-20 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="stat-item text-center">
                <div className="font-serif text-3xl lg:text-4xl font-semibold text-[#2F6BFF] mb-1">{stat.value}</div>
                <div className="text-[#6E757C] text-xs uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section ref={valuesRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">Our values</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">The principles that guide everything we do.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {values.map((value) => (
              <div key={value.title} className="value-card bg-white rounded-[14px] p-5 shadow-md hover:shadow-lg transition-shadow">
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center mb-4">
                  <value.icon size={20} className="text-[#2F6BFF]" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-[#0B0D0E] mb-2">{value.title}</h3>
                <p className="text-sm text-[#6E757C] leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-2xl mx-auto">
          <div className="bg-[#0B0D0E] rounded-[18px] p-6 lg:p-8 text-center">
            <div className="relative mb-4">
              <span className="font-serif text-5xl text-[#2F6BFF] opacity-20">"</span>
            </div>
            <blockquote className="text-base lg:text-lg text-[#F6F7F6] leading-relaxed font-medium mb-5 max-w-lg mx-auto">
              Working with LinkBoost transformed our digital presence. They didn't just get us links— 
              they got us real coverage that drove traffic, leads, and revenue.
            </blockquote>
            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/20 flex items-center justify-center">
                <span className="font-serif text-sm font-semibold text-[#2F6BFF]">MK</span>
              </div>
              <div className="text-left">
                <p className="font-medium text-[#F6F7F6] text-sm">Michael Kim</p>
                <p className="text-xs text-[#F6F7F6]/65">CEO, TechStart Inc.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-lg mx-auto text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] mb-3">Let's work together</h2>
          <p className="text-base text-[#6E757C] mb-5 max-w-md mx-auto">Ready to build authority and get featured? We'd love to hear from you.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5 hover:shadow-lg">
            Get in touch<ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
