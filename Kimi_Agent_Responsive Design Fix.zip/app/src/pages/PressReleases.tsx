import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, Newspaper, Radio, TrendingUp, Users, Calendar, FileText } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const PressReleases = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const benefitsRef = useRef<HTMLDivElement>(null);
  const processRef = useRef<HTMLDivElement>(null);
  const coverageRef = useRef<HTMLDivElement>(null);
  const faqRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.press-hero-content', { x: '-12vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' });
          gsap.fromTo('.press-hero-image', { x: '25vw', opacity: 0 }, { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out', delay: 0.15 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: benefitsRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.benefit-card', { y: 25, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: processRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.process-card', { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: coverageRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.coverage-item', { scale: 0.95, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: 'power2.out', stagger: 0.06 });
        },
        once: true,
      });

      ScrollTrigger.create({
        trigger: faqRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.press-faq-item', { y: 12, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out', stagger: 0.06 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  const benefits = [
    { icon: Radio, title: 'Media Relations', description: 'We maintain relationships with journalists and editors across top-tier publications, industry blogs, and niche outlets.' },
    { icon: FileText, title: 'Newsworthy Angles', description: 'We craft compelling stories that journalists want to cover—positioning your brand as innovative and worth watching.' },
    { icon: TrendingUp, title: 'SEO Benefits', description: 'Press mentions from authoritative news sites provide powerful backlinks that boost your search rankings.' },
    { icon: Users, title: 'Brand Awareness', description: 'Get in front of your target audience where they already consume content—building recognition and trust.' },
  ];

  const process = [
    { step: '01', title: 'Story Discovery', description: 'We identify the most newsworthy aspects of your business, product, or announcement.', icon: Calendar },
    { step: '02', title: 'Angle Development', description: 'We craft compelling narratives that align with current trends and journalist interests.', icon: FileText },
    { step: '03', title: 'Media Targeting', description: 'We identify the right journalists and publications for your story.', icon: Users },
    { step: '04', title: 'Pitch & Follow-up', description: 'We pitch your story and manage all journalist communications.', icon: Radio },
    { step: '05', title: 'Coverage & Reporting', description: 'You receive published coverage and a detailed report of all placements.', icon: Newspaper },
  ];

  const coverageTypes = [
    { type: 'Product Launches', description: 'Announce new products with coverage that drives awareness and early adoption.' },
    { type: 'Company News', description: 'Share funding rounds, acquisitions, partnerships, and milestones.' },
    { type: 'Thought Leadership', description: 'Position executives as industry experts through commentary and insights.' },
    { type: 'Data & Research', description: 'Publish original studies and data that become industry reference points.' },
    { type: 'Event Coverage', description: 'Maximize visibility around conferences, webinars, and company events.' },
    { type: 'Crisis Management', description: 'Strategic communications to protect and rebuild brand reputation.' },
  ];

  const faqs = [
    { question: 'What types of publications can you secure coverage in?', answer: 'We secure coverage across a range of outlets including top-tier tech publications (TechCrunch, VentureBeat, The Verge), industry-specific blogs, business publications (Forbes, Inc., Fast Company), and regional news outlets.' },
    { question: 'How is PR different from guest posting?', answer: 'PR focuses on news coverage and brand mentions in publications editorial content, while guest posting involves placing authored articles on blogs. PR typically generates broader brand awareness, while guest posts provide more control over messaging.' },
    { question: 'Do you write the press releases?', answer: 'Yes, we handle everything from press release writing to pitch creation. Our team has journalism backgrounds and knows what editors look for in a story.' },
    { question: 'How do you measure PR success?', answer: 'We track publication reach, domain authority of placements, social shares, referral traffic, and sentiment. You will receive a comprehensive report with all metrics and links to coverage.' },
    { question: 'What makes a story newsworthy?', answer: 'Newsworthy stories typically have timeliness, impact, proximity to current trends, prominence of people involved, or human interest. We help identify and craft angles that meet these criteria.' },
  ];

  return (
    <div className="bg-[#F6F7F6] pt-20">
      {/* Hero Section */}
      <section ref={heroRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="press-hero-content">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-0.5 bg-[#2F6BFF]" />
                <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">Press Release Service</span>
              </div>
              <h1 className="font-serif text-3xl md:text-4xl lg:text-[46px] font-semibold text-[#0B0D0E] leading-[1.08] mb-4">
                Get featured where it matters.
              </h1>
              <p className="text-base lg:text-lg text-[#6E757C] leading-relaxed mb-6 max-w-md">
                From product launches to company stories—we pitch journalists and secure placements that build credibility.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5">
                  Get started<ArrowRight size={16} />
                </Link>
                <Link to="/services" className="inline-flex items-center gap-2 px-6 py-3 border border-[#0B0D0E]/15 text-[#0B0D0E] text-sm font-medium rounded-full hover:bg-[#0B0D0E] hover:text-white transition-all">
                  View all services
                </Link>
              </div>
            </div>

            <div className="press-hero-image relative">
              <div className="relative rounded-[18px] overflow-hidden shadow-lg">
                <img src="/images/press_camera.jpg" alt="Press and media" className="w-full h-[280px] md:h-[340px] lg:h-[400px] object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section ref={benefitsRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">Why invest in PR?</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">Strategic press coverage delivers results that other marketing cannot match.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {benefits.map((benefit) => (
              <div key={benefit.title} className="benefit-card bg-white rounded-[14px] p-5 shadow-md hover:shadow-lg transition-shadow">
                <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center mb-4">
                  <benefit.icon size={20} className="text-[#2F6BFF]" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-[#0B0D0E] mb-2">{benefit.title}</h3>
                <p className="text-sm text-[#6E757C] leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section ref={processRef} className="py-8 px-6 lg:px-12 xl:px-20 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">How we get you covered</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">Our proven process turns your news into published stories.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {process.map((step) => (
              <div key={step.step} className="process-card bg-[#F6F7F6] rounded-[14px] p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-8 h-8 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center">
                    <step.icon size={16} className="text-[#2F6BFF]" />
                  </div>
                  <span className="text-2xl font-serif font-bold text-[#2F6BFF]/20">{step.step}</span>
                </div>
                <h3 className="font-serif text-base font-semibold text-[#0B0D0E] mb-1">{step.title}</h3>
                <p className="text-xs text-[#6E757C] leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Coverage Types */}
      <section ref={coverageRef} className="py-8 px-6 lg:px-12 xl:px-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#0B0D0E] mb-3">What we can promote</h2>
            <p className="text-base text-[#6E757C] max-w-md mx-auto">From launches to leadership—if it is newsworthy, we can get it covered.</p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {coverageTypes.map((item) => (
              <div key={item.type} className="coverage-item bg-white rounded-[12px] p-4 shadow-md hover:shadow-lg transition-shadow">
                <h3 className="font-serif text-base font-semibold text-[#0B0D0E] mb-1">{item.type}</h3>
                <p className="text-xs text-[#6E757C] leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section ref={faqRef} className="py-8 px-6 lg:px-12 xl:px-20 bg-white">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] mb-3">Frequently asked questions</h2>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div key={index} className="press-faq-item bg-[#F6F7F6] rounded-[12px] p-4">
                <h3 className="font-medium text-sm text-[#0B0D0E] mb-2 flex items-start gap-2">
                  <Check size={16} className="text-[#2F6BFF] mt-0.5 flex-shrink-0" />
                  {faq.question}
                </h3>
                <p className="text-xs text-[#6E757C] leading-relaxed pl-6">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-lg mx-auto text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold text-[#0B0D0E] mb-3">Ready to get media coverage?</h2>
          <p className="text-base text-[#6E757C] mb-5 max-w-sm mx-auto">Let's discuss your news and create a PR strategy that gets you featured.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5 hover:shadow-lg">
            Request a proposal<ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default PressReleases;
