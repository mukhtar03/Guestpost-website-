import { useState, useEffect, useRef } from 'react';
import { Mail, MapPin, Send, CheckCircle } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    website: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: formRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo('.contact-content', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' });
          gsap.fromTo('.contact-form', { x: 25, opacity: 0 }, { x: 0, opacity: 1, duration: 0.7, ease: 'power2.out', delay: 0.15 });
        },
        once: true,
      });
    });

    return () => ctx.revert();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="bg-[#F6F7F6] pt-20">
      {/* Hero Section */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-2xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-0.5 bg-[#2F6BFF]" />
            <span className="text-xs font-semibold uppercase tracking-wider text-[#6E757C]">Contact Us</span>
            <div className="w-8 h-0.5 bg-[#2F6BFF]" />
          </div>
          <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-[#0B0D0E] leading-[1.08] mb-4">
            Ready to get featured?
          </h1>
          <p className="text-base lg:text-lg text-[#6E757C] max-w-lg mx-auto leading-relaxed">
            Tell us what you're building. We'll reply with a plan, timeline, and pricing within 24 hours.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section ref={formRef} className="py-6 px-6 lg:px-12 xl:px-20">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-10">
            {/* Left Content */}
            <div className="contact-content lg:col-span-2">
              <div className="mb-5">
                <h2 className="font-serif text-xl font-semibold text-[#0B0D0E] mb-2">Let's start a conversation</h2>
                <p className="text-sm text-[#6E757C] leading-relaxed">
                  Whether you're looking for guest posts, press coverage, or just want to learn more 
                  about how we work—we're here to help.
                </p>
              </div>

              <div className="space-y-3 mb-5">
                <a href="mailto:hello@linkboost.io" className="flex items-center gap-3 group">
                  <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center group-hover:bg-[#2F6BFF]/20 transition-colors">
                    <Mail size={18} className="text-[#2F6BFF]" />
                  </div>
                  <div>
                    <p className="text-xs text-[#6E757C] mb-0.5">Email us</p>
                    <p className="text-sm text-[#0B0D0E] font-medium group-hover:text-[#2F6BFF] transition-colors">hello@linkboost.io</p>
                  </div>
                </a>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center">
                    <MapPin size={18} className="text-[#2F6BFF]" />
                  </div>
                  <div>
                    <p className="text-xs text-[#6E757C] mb-0.5">Location</p>
                    <p className="text-sm text-[#0B0D0E] font-medium">Based worldwide — UTC to PST</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-[14px] p-4 shadow-md">
                <h3 className="font-serif text-base font-semibold text-[#0B0D0E] mb-3">What happens next?</h3>
                <ol className="space-y-2 text-sm text-[#6E757C]">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0 text-xs font-medium text-[#2F6BFF]">1</span>
                    We review your submission within 24 hours
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0 text-xs font-medium text-[#2F6BFF]">2</span>
                    We schedule a call to discuss your goals
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center flex-shrink-0 text-xs font-medium text-[#2F6BFF]">3</span>
                    You receive a custom proposal with pricing
                  </li>
                </ol>
              </div>
            </div>

            {/* Right Form */}
            <div className="contact-form lg:col-span-3">
              {isSubmitted ? (
                <div className="bg-white rounded-[18px] p-8 shadow-md text-center">
                  <div className="w-14 h-14 rounded-full bg-[#2F6BFF]/10 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle size={28} className="text-[#2F6BFF]" />
                  </div>
                  <h3 className="font-serif text-xl font-semibold text-[#0B0D0E] mb-2">Message sent!</h3>
                  <p className="text-sm text-[#6E757C] leading-relaxed">
                    Thank you for reaching out. We'll get back to you within 24 hours with a personalized proposal.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="bg-white rounded-[18px] p-5 lg:p-6 shadow-md">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-[#0B0D0E] mb-1.5">Name</label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full px-3 py-2.5 rounded-[10px] border border-[#0B0D0E]/10 focus:border-[#2F6BFF] focus:ring-2 focus:ring-[#2F6BFF]/20 outline-none transition-all text-sm text-[#0B0D0E] placeholder:text-[#6E757C]/50"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-[#0B0D0E] mb-1.5">Email</label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="w-full px-3 py-2.5 rounded-[10px] border border-[#0B0D0E]/10 focus:border-[#2F6BFF] focus:ring-2 focus:ring-[#2F6BFF]/20 outline-none transition-all text-sm text-[#0B0D0E] placeholder:text-[#6E757C]/50"
                          placeholder="you@company.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="website" className="block text-sm font-medium text-[#0B0D0E] mb-1.5">Website</label>
                      <input
                        type="url"
                        id="website"
                        name="website"
                        value={formData.website}
                        onChange={handleChange}
                        className="w-full px-3 py-2.5 rounded-[10px] border border-[#0B0D0E]/10 focus:border-[#2F6BFF] focus:ring-2 focus:ring-[#2F6BFF]/20 outline-none transition-all text-sm text-[#0B0D0E] placeholder:text-[#6E757C]/50"
                        placeholder="https://yourcompany.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-[#0B0D0E] mb-1.5">What are you working on?</label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        rows={4}
                        className="w-full px-3 py-2.5 rounded-[10px] border border-[#0B0D0E]/10 focus:border-[#2F6BFF] focus:ring-2 focus:ring-[#2F6BFF]/20 outline-none transition-all text-sm text-[#0B0D0E] placeholder:text-[#6E757C]/50 resize-none"
                        placeholder="Tell us about your goals, target audience, and what you're hoping to achieve..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#2F6BFF] text-white text-sm font-medium rounded-full hover:bg-[#1a5aee] transition-all hover:-translate-y-0.5"
                    >
                      Request a proposal<Send size={16} />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Preview */}
      <section className="py-10 px-6 lg:px-12 xl:px-20">
        <div className="max-w-md mx-auto text-center">
          <h2 className="font-serif text-xl font-semibold text-[#0B0D0E] mb-3">Have questions?</h2>
          <p className="text-sm text-[#6E757C] mb-4">Check out our service pages for detailed FAQs about guest posts and press releases.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <a href="/services/guest-posts" className="inline-flex items-center gap-2 px-5 py-2.5 border border-[#0B0D0E]/15 text-[#0B0D0E] text-sm font-medium rounded-full hover:bg-[#0B0D0E] hover:text-white transition-all">
              Guest Posts FAQ
            </a>
            <a href="/services/press-releases" className="inline-flex items-center gap-2 px-5 py-2.5 border border-[#0B0D0E]/15 text-[#0B0D0E] text-sm font-medium rounded-full hover:bg-[#0B0D0E] hover:text-white transition-all">
              Press Releases FAQ
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
