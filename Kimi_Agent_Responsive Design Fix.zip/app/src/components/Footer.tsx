import { Link } from 'react-router-dom';
import { Mail, MapPin, ArrowRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#0B0D0E] text-[#F6F7F6]">
      <div className="w-full px-4 sm:px-6 lg:px-10 py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">
          {/* Left Column */}
          <div className="space-y-6">
            <div>
              <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-semibold mb-3">
                Ready to get featured?
              </h2>
              <p className="text-[#F6F7F6]/65 text-sm lg:text-base max-w-sm leading-relaxed">
                Tell us what you're building. We'll reply with a plan, timeline, and pricing within 24 hours.
              </p>
            </div>
            
            <div className="space-y-3">
              <a
                href="mailto:hello@linkboost.io"
                className="flex items-center gap-2 text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors text-sm"
              >
                <Mail size={16} />
                <span>hello@linkboost.io</span>
              </a>
              <div className="flex items-center gap-2 text-[#F6F7F6]/65 text-sm">
                <MapPin size={16} />
                <span>Based worldwide — UTC to PST</span>
              </div>
            </div>
          </div>

          {/* Right Column - Quick Links */}
          <div className="grid grid-cols-2 gap-6 lg:gap-8">
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider mb-3 text-[#F6F7F6]/50">
                Services
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/services/guest-posts"
                    className="text-sm text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors flex items-center gap-1.5 group"
                  >
                    Guest Posts
                    <ArrowRight size={12} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
                <li>
                  <Link
                    to="/services/press-releases"
                    className="text-sm text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors flex items-center gap-1.5 group"
                  >
                    Press Releases
                    <ArrowRight size={12} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
                <li>
                  <Link
                    to="/services"
                    className="text-sm text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors flex items-center gap-1.5 group"
                  >
                    All Services
                    <ArrowRight size={12} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider mb-3 text-[#F6F7F6]/50">
                Company
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/about"
                    className="text-sm text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors flex items-center gap-1.5 group"
                  >
                    About Us
                    <ArrowRight size={12} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="text-sm text-[#F6F7F6]/65 hover:text-[#2F6BFF] transition-colors flex items-center gap-1.5 group"
                  >
                    Contact
                    <ArrowRight size={12} className="opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-[#F6F7F6]/10 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-[#F6F7F6]/50 text-xs">
            © LinkBoost Digital. All rights reserved.
          </p>
          <Link to="/" className="font-serif text-lg font-semibold text-[#F6F7F6]">
            LinkBoost
          </Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
